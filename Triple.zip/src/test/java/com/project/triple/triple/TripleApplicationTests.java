package com.project.triple.triple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TripleApplicationTests {

    @Test
    void contextLoads() {
    }

}
