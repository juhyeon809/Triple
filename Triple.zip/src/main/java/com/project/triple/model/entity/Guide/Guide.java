package com.project.triple.model.entity.Guide;


import com.project.triple.model.entity.User.AdminUser;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@SequenceGenerator(
        name="seq_guide",
        sequenceName = "seq_guide",
        initialValue = 1,
        allocationSize = 1
)
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Guide {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_guide")
    private Long idx;
    private String type;
    private Integer guideNum;
//    private String adminuserId;
    private String country;
    private String adminuserName;
    private String title;
    private String content;
    private String uploadPath;
    private String fileName;
    private String fileType;
    @CreatedDate
    private LocalDateTime regDate;
    private Integer reviewCount;

    @ManyToOne
    private AdminUser adminUser;

}
